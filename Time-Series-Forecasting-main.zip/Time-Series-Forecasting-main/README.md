# Time Series Analysis, compare results of 5 different models and gives the best model
# Built using Streamlit, Docker
# Commands: 
          cd ml-docker-app
          docker build -t ml_model .
          docker run -p 8501:8501 ml_model

